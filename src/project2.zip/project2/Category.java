package project2;


	public enum Category {
		NEW, CERTIFIED, USED
	}

